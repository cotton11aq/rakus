const a = 10;
const b = 2;

console.log(`加算 ${a}+${b}=${a + b}`);
console.log(`減算 ${a}-${b}=${a - b}`);
console.log(`乗算 ${a}*${b}=${a * b}`);
console.log(`除算 ${a}/${b}=${a / b}`);
console.log(`剰余算 ${a}%${b}=${a % b}`);
