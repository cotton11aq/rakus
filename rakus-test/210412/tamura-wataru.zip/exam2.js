const myName = '田村渉';

console.log(myName);
console.log(myName);
console.log(myName);
